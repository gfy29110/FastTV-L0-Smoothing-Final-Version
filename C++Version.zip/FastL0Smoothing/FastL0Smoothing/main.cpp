#include "mainwindow.h"
#include <QtWidgets/QApplication>
#include <qdir.h>

int main(int argc, char *argv[])
{
	QDir::setCurrent(QCoreApplication::applicationDirPath());
	QApplication a(argc, argv);
	MainWindow w;
	w.show();
	return a.exec();
}
