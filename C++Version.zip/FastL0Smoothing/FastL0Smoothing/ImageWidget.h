#pragma once
#include <QWidget>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "cv.h"
#include "highgui.h"
#include <iostream>
#include <iosfwd>
#include <fstream>
#include <iomanip>
#include <time.h>
#include <math.h>

QT_BEGIN_NAMESPACE
class QImage;
class QPainter;
QT_END_NAMESPACE

using namespace cv;
using namespace std;

class ImageWidget :
	public QWidget
{
	Q_OBJECT

public:
	ImageWidget(void);
	~ImageWidget(void);
	void set_omega(float omega_);

signals:
	void mysignal(int progress_);
	void mytime();

public:
	int get_progress();
	float get_time();

protected:
	void paintEvent(QPaintEvent *paintevent);

public slots:
	// File IO
	void Open();												// Open an image file, support ".bmp, .png, .jpg" format
	void Save();												// Save image to current file
	void SaveAs();												// Save image to another file

	// Image processing
	void Penalty_Method_L0Smoothing();											// L0Smoothing in gradient field in Penalty Method
	void ADMM_L0Smoothing();													// L0Smoothing in gradient field in ADMM
	void Penalty_Method_L0Smoothing1();											// L0Smoothing in gradient field in Penalty Method in L21 residue norm
	void ADMM_L0Smoothing1();													// L0Smoothing in gradient field in ADMM in L21 residue norm

private:
	QImage		*ptr_image_;				// image 
	QImage		*ptr_image_backup_;
	int M, N;
	Mat S_x, S_y, Z_x, Z_y, I_x, I_y, I, U_x, U_y, U_t, R_x, R_y, R_t, Dete_Z_x, Dete_Z_y;
	int progress;
	float omega;
	int step;
	float time;


	void UpdateS(float mu);
	void UpdateZ(float mu);
	void UpdateS_ADMM(float mu);
	void UpdateZ_ADMM(float mu);
	void UpdateR_ADMM();
	void UpdateU_ADMM();
	void UpdateS1(float mu);
	void UpdateS_ADMM1(float mu);
	float getDeteR();
	float getDeteS();
	float R_max();
	float S_max();
	float R_Stop_Iter();
	float S_Stop_Iter();
	void WriteCheck();
	void Reconstruct();
	void writeMatToFile(cv::Mat& m, const char* filename);		//For Debug
	void SetDiff();
};

