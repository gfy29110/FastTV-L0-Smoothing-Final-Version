/********************************************************************************
** Form generated from reading UI file 'fastl0smoothing.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FASTL0SMOOTHING_H
#define UI_FASTL0SMOOTHING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FastL0SmoothingClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *FastL0SmoothingClass)
    {
        if (FastL0SmoothingClass->objectName().isEmpty())
            FastL0SmoothingClass->setObjectName(QStringLiteral("FastL0SmoothingClass"));
        FastL0SmoothingClass->resize(600, 400);
        menuBar = new QMenuBar(FastL0SmoothingClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        FastL0SmoothingClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(FastL0SmoothingClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        FastL0SmoothingClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(FastL0SmoothingClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        FastL0SmoothingClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(FastL0SmoothingClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        FastL0SmoothingClass->setStatusBar(statusBar);

        retranslateUi(FastL0SmoothingClass);

        QMetaObject::connectSlotsByName(FastL0SmoothingClass);
    } // setupUi

    void retranslateUi(QMainWindow *FastL0SmoothingClass)
    {
        FastL0SmoothingClass->setWindowTitle(QApplication::translate("FastL0SmoothingClass", "FastL0Smoothing", 0));
    } // retranslateUi

};

namespace Ui {
    class FastL0SmoothingClass: public Ui_FastL0SmoothingClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FASTL0SMOOTHING_H
