#include "ImageWidget.h"
#include <QImage>
#include <QPainter>
#include <QtWidgets> 
#include <iostream>


using std::cout;
using std::endl;

ImageWidget::ImageWidget(void)
{
	ptr_image_ = new QImage();
	ptr_image_backup_ = new QImage();
	omega = 2;
	progress = 20;
	M = 0;
	N = 0;
	step = 0;
}


ImageWidget::~ImageWidget(void)
{
}

void ImageWidget::paintEvent(QPaintEvent *paintevent)
{
	QPainter painter;
	painter.begin(this);

	// Draw background
	painter.setBrush(Qt::lightGray);
	QRect back_rect(0, 0, width(), height());
	painter.drawRect(back_rect);

	// Draw image
	QRect rect = QRect( (width()-ptr_image_->width())/2, (height()-ptr_image_->height())/2, ptr_image_->width(), ptr_image_->height());
	painter.drawImage(rect, *ptr_image_); 

	painter.end();
}

void ImageWidget::Open()
{
	// Open file
	QString fileName = QFileDialog::getOpenFileName(this, tr("Read Image"), ".", tr("Images(*.bmp *.png *.jpg)"));

	// Load file
	if (!fileName.isEmpty())
	{
		ptr_image_->load(fileName);
		*(ptr_image_backup_) = *(ptr_image_);
	}
	cout<<"image size: "<<ptr_image_->width()<<' '<<ptr_image_->height()<<endl;
	M = ptr_image_->height();
	N = ptr_image_->width();
	int sz[] = { 3, M, N };
	int sz_x[] = { 3, M, N - 1 };
	int sz_y[] = { 3, M - 1, N };
	I = cv::Mat::zeros(M, N, CV_32FC3);
	
	Mat I_rgb[] = { cv::Mat::zeros(M, N, CV_32F), cv::Mat::zeros(M, N, CV_32F), cv::Mat::zeros(M, N, CV_32F) };
	float *pI_r, *pI_g, *pI_b;
	for (int i = 0; i < M; i++){
		pI_r = I_rgb[0].ptr<float>(i);
		pI_g = I_rgb[1].ptr<float>(i);
		pI_b = I_rgb[2].ptr<float>(i);
		for (int j = 0; j < N; j++){
			QRgb temp = ptr_image_->pixel(j, i);
			int r = qRed(temp);
			int g = qGreen(temp);
			int b = qBlue(temp);
			pI_r[j] = (float)r / 256;
			pI_g[j] = (float)g / 256;
			pI_b[j] = (float)b / 256;
		}
	}
	merge(I_rgb, 3, I);
	
}
void ImageWidget::writeMatToFile(cv::Mat& m, const char* filename)
{
	std::ofstream fout(filename);
	float input;

	if (!fout)
	{
		std::cout << "File Not Opened" << std::endl;
		return;
	}

	for (int i = 0; i<m.rows; i++)
	{
		for (int j = 0; j<m.cols; j++)
		{
			input = m.at<float>(i, j);
			fout << fixed << setprecision(5) << input << "\t";
		}
		fout << std::endl;
		fout << std::endl;
	}

	fout.close();
}

void ImageWidget::Save()
{
	SaveAs();
}

void ImageWidget::SaveAs()
{
	QString filename = QFileDialog::getSaveFileName(this, tr("Save Image"), ".", tr("Images(*.bmp *.png *.jpg)"));
	if (filename.isNull())
	{
		return;
	}	

	ptr_image_->save(filename);
}

float sumMat(Mat& inputImg)
{
	float sum = 0.0;
	int rowNumber = inputImg.rows;
	int colNumber = inputImg.cols * inputImg.channels();
	for (int i = 0; i < rowNumber; i++)
	{
		uchar* data = inputImg.ptr<uchar>(i);
		for (int j = 0; j < colNumber; j++)
		{
			sum = data[j] + sum;
		}
	}
	return sum;
}

void ImageWidget::UpdateZ(float mu)
{
	Mat ZA = S_x.rowRange(0, M - 1).clone();
	Mat ZB = S_y.colRange(0, N - 1).clone();
	Mat ZC = S_x.rowRange(1, M).clone() - S_y.colRange(1, N).clone();
	Mat Z_judge = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
	Mat Z_square = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
	int p = 2;
	pow(ZA.clone(), p, Z_square);
	Z_judge = Z_judge + Z_square;
	pow(ZB.clone(), p, Z_square);
	Z_judge = Z_judge + Z_square;
	pow(ZC.clone(), p, Z_square);
	Z_judge = Z_judge + Z_square;
	pow(ZA.clone() - ZB.clone() - ZC.clone(), p, Z_square);
	Z_square = Z_square / 3;
	Z_judge = Z_judge - Z_square;
	Mat Z_bool_single = Z_judge > 2 / mu;
	Z_bool_single.convertTo(Z_bool_single, CV_32F);
	Z_bool_single = Z_bool_single / 255;
	Mat Z_x_new, Z_y_new;
	Z_x_new = (ZA * 2 + ZB + ZC) / 3.0;
	Z_y_new = (ZA + ZB * 2 - ZC) / 3.0;
	Z_x_new = Z_x_new.mul(Z_bool_single);
	Z_x_new.copyTo(Z_x.rowRange(0, M - 1));
	Z_y_new = Z_y_new.mul(Z_bool_single);
	Z_y_new.copyTo(Z_y.colRange(0, N - 1));
	Z_x_new.release();
	Z_y_new.release();
	ZA.release();
	ZB.release();
	ZC.release();
	S_x.row(M - 1).copyTo(Z_x.row(M - 1));
	S_y.col(N - 1).copyTo(Z_y.col(N - 1));
	Z_judge.release();
	Z_square.release();
	Z_bool_single.release();
	
}

void ImageWidget::UpdateS(float mu){
	Mat SA = I_x.rowRange(1, M).clone()*omega + Z_x.rowRange(1, M).clone()*mu;
	Mat SB = I_y.colRange(1, N).clone()*omega + Z_y.colRange(1, N).clone()*mu;
	Mat SC = (Z_x.rowRange(0, M - 1).clone() - Z_y.colRange(0, N - 1).clone())*mu;
	float MS_time = mu/((omega + mu)*(omega + 3 * mu));
	Mat MS = (SA.clone() + SB.clone())*MS_time;
	float beta = 1.0 / (omega + 3 * mu);
	Mat S_x_new = (SA.clone() + SC.clone())*beta + MS.clone();
	Mat S_y_new = (SB.clone() - SC.clone())*beta + MS.clone();
	S_x_new.copyTo(S_x.rowRange(1, M));
	S_y_new.copyTo(S_y.colRange(1, N));
	Z_x.row(0).copyTo(S_x.row(0));
	Z_y.col(0).copyTo(S_y.col(0));
	SA.release();
	SB.release();
	SC.release();
	MS.release();
}

int round_double(double number)
{
	int k = floor(number);
	k = (k < 0) ? 0 : k;
	k = (k > 255) ? 255 : k;
	return (k);
}

void ImageWidget::Reconstruct(){
	double lambda = 10000.0;
	//This part may be inefficiency......
	Mat otfFx_real = cv::Mat::zeros(M, N, CV_32F);
	Mat otfFy_real = cv::Mat::zeros(M, N, CV_32F);

	float* ptr = otfFx_real.ptr<float>(0);
	ptr[0] = -1.0;
	ptr[N - 1] = 1.0;
	ptr = otfFy_real.ptr<float>(0);
	ptr[0] = -1.0;
	ptr = otfFy_real.ptr<float>(M - 1);
	ptr[0] = 1.0;

	Mat otfFx[] = { cv::Mat_<float>(otfFx_real), cv::Mat::zeros(otfFx_real.size(), CV_32F) };
	Mat otfFy[] = { cv::Mat_<float>(otfFy_real), cv::Mat::zeros(otfFy_real.size(), CV_32F) };

	Mat otfFx_complex, otfFy_complex;
	merge(otfFx, 2, otfFx_complex);
	merge(otfFy, 2, otfFy_complex);

	Mat f_otfFx_complex, f_otfFy_complex;
	dft(otfFx_complex, f_otfFx_complex);
	dft(otfFy_complex, f_otfFy_complex);

	split(f_otfFx_complex, otfFx);
	split(f_otfFy_complex, otfFy);

	otfFx_complex.release();
	otfFy_complex.release(); 
	otfFx_real.release();
	otfFy_real.release();
	f_otfFx_complex.release();
	f_otfFy_complex.release();
	//66,67,68th line, prepare for otfFx & otfFy
	Mat I_rgb[3];
	split(I, I_rgb);

	Mat I_r[] = { cv::Mat_<float>(I_rgb[0]), cv::Mat::zeros(I_rgb[0].size(), CV_32F) };
	Mat I_g[] = { cv::Mat_<float>(I_rgb[1]), cv::Mat::zeros(I_rgb[1].size(), CV_32F) };
	Mat I_b[] = { cv::Mat_<float>(I_rgb[2]), cv::Mat::zeros(I_rgb[2].size(), CV_32F) };

	Mat I_r_complex, I_g_complex, I_b_complex;
	merge(I_r, 2, I_r_complex);
	merge(I_g, 2, I_g_complex);
	merge(I_b, 2, I_b_complex);

	Mat f_I_r_complex, f_I_g_complex, f_I_b_complex;
	dft(I_r_complex, f_I_r_complex);
	dft(I_g_complex, f_I_g_complex);
	dft(I_b_complex, f_I_b_complex);

	I_r[0].release();
	I_g[0].release();
	I_b[0].release();
	I_r[1].release();
	I_g[1].release();
	I_b[1].release();
	I_r_complex.release();
	I_g_complex.release();
	I_b_complex.release();
	
	//69th line
	Mat Denormin_real = otfFx[0].mul(otfFx[0]) + otfFx[1].mul(otfFx[1]) + otfFy[0].mul(otfFy[0]) + otfFy[1].mul(otfFy[1]);

	otfFx[0].release();
	otfFy[0].release();
	otfFx[1].release();
	otfFy[1].release();

	Denormin_real = 1 + lambda * Denormin_real;

	Mat S_x_exp, S_y_exp;
	hconcat(S_x, I.col(0).clone() - I.col(N - 1).clone(), S_x_exp);
	vconcat(S_y, I.row(0).clone() - I.row(M - 1).clone(), S_y_exp);

	//75,76th line

	Mat Normin = cv::Mat::zeros(M, N, CV_32FC3);
	Normin.col(0) = Normin.col(0) + S_x_exp.col(N - 1) - S_x_exp.col(0);
	for (int i = 1; i < N; i++){
		Normin.col(i) = Normin.col(i) + S_x_exp.col(i - 1) - S_x_exp.col(i);
	}
	Normin.row(0) = Normin.row(0) + S_y_exp.row(M - 1) - S_y_exp.row(0);
	for (int j = 1; j < M; j++){
		Normin.row(j) = Normin.row(j) + S_y_exp.row(j - 1) - S_y_exp.row(j);
	}

	S_x_exp.release();
	S_y_exp.release();

	//77,78th line
	Mat S_rgb[3];
	split(Normin, S_rgb);

	Mat S_r[] = { cv::Mat_<float>(S_rgb[0]), cv::Mat::zeros(S_rgb[0].size(), CV_32F) };
	Mat S_g[] = { cv::Mat_<float>(S_rgb[1]), cv::Mat::zeros(S_rgb[1].size(), CV_32F) };
	Mat S_b[] = { cv::Mat_<float>(S_rgb[2]), cv::Mat::zeros(S_rgb[2].size(), CV_32F) };
	
	Mat S_r_complex, S_g_complex, S_b_complex;
	merge(S_r, 2, S_r_complex);
	merge(S_g, 2, S_g_complex);
	merge(S_b, 2, S_b_complex);

	Mat f_S_r_complex, f_S_g_complex, f_S_b_complex;
	dft(S_r_complex, f_S_r_complex);
	dft(S_g_complex, f_S_g_complex);
	dft(S_b_complex, f_S_b_complex);

	Normin.release();
	S_rgb[0].release();
	S_rgb[1].release();
	S_rgb[2].release();
	S_r[0].release();
	S_g[0].release();
	S_b[0].release();
	S_r[1].release();
	S_g[1].release();
	S_b[1].release();
	S_r_complex.release();
	S_g_complex.release();
	S_b_complex.release();

	//prepare for fft2(Normin2)
	Mat FS_r_complex = (f_I_r_complex + lambda * f_S_r_complex);
	Mat FS_g_complex = (f_I_g_complex + lambda * f_S_g_complex);
	Mat FS_b_complex = (f_I_b_complex + lambda * f_S_b_complex);

	f_S_r_complex.release();
	f_S_g_complex.release();
	f_S_b_complex.release();
	f_I_r_complex.release();
	f_I_g_complex.release();
	f_I_b_complex.release();

	Mat FS_r[2], FS_g[2], FS_b[2];
	split(FS_r_complex, FS_r);
	split(FS_g_complex, FS_g);
	split(FS_b_complex, FS_b);

	Mat new_FS_r_r = FS_r[0].mul(1 / Denormin_real);
	Mat new_FS_g_r = FS_g[0].mul(1 / Denormin_real);
	Mat new_FS_b_r = FS_b[0].mul(1 / Denormin_real);
	Mat new_FS_r_i = FS_r[1].mul(1 / Denormin_real);
	Mat new_FS_g_i = FS_g[1].mul(1 / Denormin_real);
	Mat new_FS_b_i = FS_b[1].mul(1 / Denormin_real);

	new_FS_r_r.copyTo(FS_r[0]);
	new_FS_g_r.copyTo(FS_g[0]);
	new_FS_b_r.copyTo(FS_b[0]);
	new_FS_r_i.copyTo(FS_r[1]);
	new_FS_g_i.copyTo(FS_g[1]);
	new_FS_b_i.copyTo(FS_b[1]);

	merge(FS_r, 2, FS_r_complex);
	merge(FS_g, 2, FS_g_complex);
	merge(FS_b, 2, FS_b_complex);

	FS_r[0].release();
	FS_g[0].release();
	FS_b[0].release();
	FS_r[1].release();
	FS_g[1].release();
	FS_b[1].release();

	//79th line
	Mat if_FS_r_complex, if_FS_g_complex, if_FS_b_complex;
	idft(FS_r_complex, if_FS_r_complex, DFT_REAL_OUTPUT);
	idft(FS_g_complex, if_FS_g_complex, DFT_REAL_OUTPUT);
	idft(FS_b_complex, if_FS_b_complex, DFT_REAL_OUTPUT);

	FS_r_complex.release();
	FS_g_complex.release();
	FS_b_complex.release();

	Mat S_r_r = if_FS_r_complex / (M*N);
	Mat S_g_r = if_FS_g_complex / (M*N);
	Mat S_b_r = if_FS_b_complex / (M*N);

	I_rgb[0] = cv::Mat_<float>(S_r_r.clone());
	I_rgb[1] = cv::Mat_<float>(S_g_r.clone());
	I_rgb[2] = cv::Mat_<float>(S_b_r.clone());

	S_r_r.release();
	S_g_r.release();
	S_b_r.release();

	merge(I_rgb, 3, I);
	//80th line
	for (int i = 0; i < M; i++){
		for (int j = 0; j < N; j++){
			QRgb pixel_ptr = qRgb(round_double(I_rgb[0].at<float>(i, j) * 256), round_double(I_rgb[1].at<float>(i, j) * 256), round_double(I_rgb[2].at<float>(i, j) * 256));
			ptr_image_->setPixel(j, i, pixel_ptr);
		}
	}

	I_rgb[0].release();
	I_rgb[1].release();
	I_rgb[2].release();
}

void ImageWidget::WriteCheck(){
	Mat S_x_rgb[3], S_y_rgb[3];
	split(S_x, S_x_rgb);
	split(S_y, S_y_rgb);
	writeMatToFile(S_x_rgb[0], "E:\\ѧϰ\\��Ŀ\\FastTV��Ŀ\\C++Version\\FastL0Smoothing\\FastL0Smoothing\\data\\S_x_r.txt");
	writeMatToFile(S_x_rgb[1], "E:\\ѧϰ\\��Ŀ\\FastTV��Ŀ\\C++Version\\FastL0Smoothing\\FastL0Smoothing\\data\\S_x_g.txt");
	writeMatToFile(S_x_rgb[2], "E:\\ѧϰ\\��Ŀ\\FastTV��Ŀ\\C++Version\\FastL0Smoothing\\FastL0Smoothing\\data\\S_x_b.txt");
	writeMatToFile(S_y_rgb[0], "E:\\ѧϰ\\��Ŀ\\FastTV��Ŀ\\C++Version\\FastL0Smoothing\\FastL0Smoothing\\data\\S_y_r.txt");
	writeMatToFile(S_y_rgb[1], "E:\\ѧϰ\\��Ŀ\\FastTV��Ŀ\\C++Version\\FastL0Smoothing\\FastL0Smoothing\\data\\S_y_g.txt");
	writeMatToFile(S_y_rgb[2], "E:\\ѧϰ\\��Ŀ\\FastTV��Ŀ\\C++Version\\FastL0Smoothing\\FastL0Smoothing\\data\\S_y_b.txt");
}
void ImageWidget::Penalty_Method_L0Smoothing(){
	if (M>3 && N>3){
		float t1 = clock();
		float mu = 0.04;
		float mu_max = 10000;
		progress = 0;
		emit mysignal(progress);
		SetDiff();
		progress++;
		emit mysignal(progress);
		while (mu < mu_max){
			UpdateZ(mu);
			progress++;
			emit mysignal(progress);
			UpdateS(mu);
			mu *= 2;
			progress++;
			emit mysignal(progress);
		}
		//WriteCheck();
		Reconstruct();
		progress = 40;
		emit mysignal(progress);
		update();
		float t2 = clock();
		time = (t2 - t1) / CLOCKS_PER_SEC;
		emit mytime();
	}
}

void ImageWidget::set_omega(float omega_){
	omega = omega_;
}

int ImageWidget::get_progress(){
	return progress;
}

void ImageWidget::SetDiff(){
	I_x = cv::Mat::zeros(M, N - 1, CV_32FC3);
	S_x = cv::Mat::zeros(M, N - 1, CV_32FC3);
	Z_x = cv::Mat::zeros(M, N - 1, CV_32FC3);
	U_x = cv::Mat::zeros(M, N - 1, CV_32FC3);
	R_x = cv::Mat::zeros(M, N - 1, CV_32FC3);
	I_y = cv::Mat::zeros(M - 1, N, CV_32FC3);
	S_y = cv::Mat::zeros(M - 1, N, CV_32FC3);
	Z_y = cv::Mat::zeros(M - 1, N, CV_32FC3);
	U_y = cv::Mat::zeros(M - 1, N, CV_32FC3);
	R_y = cv::Mat::zeros(M - 1, N, CV_32FC3);
	U_t = cv::Mat::zeros(M - 1, N - 1, CV_32FC3); 
	R_t = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
	Dete_Z_x = cv::Mat::zeros(M, N - 1, CV_32FC3);
	Dete_Z_y = cv::Mat::zeros(M - 1, N, CV_32FC3);
	Mat win_x = (Mat_<float>(1, 2) << -1.0, 1.0);
	filter2D(I, I_x, I.depth(), win_x, Point(0, 0));
	Mat win_y = (Mat_<float>(2, 1) << -1.0, 1.0);
	filter2D(I, I_y, I.depth(), win_y, Point(0, 0));
	I_x = I_x.colRange(0, N - 1);
	I_y = I_y.rowRange(0, M - 1);
	S_x = I_x.clone();
	Z_x = I_x.clone();
	S_y = I_y.clone();
	Z_y = I_y.clone();
}

float ImageWidget::get_time(){
	return time;
}

void ImageWidget::UpdateZ_ADMM(float mu)
{
	Mat ZA = S_x.rowRange(0, M - 1).clone() + U_x.rowRange(0, M - 1);
	Mat ZB = S_y.colRange(0, N - 1).clone() + U_y.colRange(0, N - 1);
	Mat ZC = S_x.rowRange(1, M).clone() - S_y.colRange(1, N).clone() + U_t.clone();
	Mat Z_judge = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
	Mat Z_square = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
	int p = 2;
	pow(ZA.clone(), p, Z_square);
	Z_judge = Z_judge + Z_square;
	pow(ZB.clone(), p, Z_square);
	Z_judge = Z_judge + Z_square;
	pow(ZC.clone(), p, Z_square);
	Z_judge = Z_judge + Z_square;
	pow(ZA.clone() - ZB.clone() - ZC.clone(), p, Z_square);
	Z_square = Z_square / 3;
	Z_judge = Z_judge - Z_square;
	Mat Z_bool_single = Z_judge > 2 / mu;
	Z_bool_single.convertTo(Z_bool_single, CV_32F);
	Z_bool_single = Z_bool_single / 255;
	Mat Z_x_new, Z_y_new;
	Z_x_new = (ZA * 2 + ZB + ZC) / 3.0;
	Z_y_new = (ZA + ZB * 2 - ZC) / 3.0;
	Mat Dete_Z_x_new = Z_x_new - Z_x.rowRange(0, M - 1);
	Mat Dete_Z_y_new = Z_y_new - Z_y.colRange(0, N - 1);
	Dete_Z_x_new.copyTo(Dete_Z_x.rowRange(0, M - 1));
	Dete_Z_y_new.copyTo(Dete_Z_y.colRange(0, N - 1));
	Z_x_new = Z_x_new.mul(Z_bool_single);
	Z_x_new.copyTo(Z_x.rowRange(0, M - 1));
	Z_y_new = Z_y_new.mul(Z_bool_single);
	Z_y_new.copyTo(Z_y.colRange(0, N - 1));
	Z_x_new.release();
	Z_y_new.release();
	ZA.release();
	ZB.release();
	ZC.release();
	Mat row_exp = S_x.row(M - 1) + U_x.row(M - 1);
	Mat col_exp = S_y.col(N - 1) + U_y.col(N - 1);
	Mat dete_row = S_x.row(M - 1) + U_x.row(M - 1) - Z_x.row(M - 1);
	Mat dete_col = S_y.col(N - 1) + U_y.col(N - 1) - Z_y.col(N - 1);
	row_exp.copyTo(Z_x.row(M - 1));
	col_exp.copyTo(Z_y.col(N - 1));
	dete_row.copyTo(Dete_Z_x.row(M - 1));
	dete_col.copyTo(Dete_Z_y.col(N - 1));
	Z_judge.release();
	Z_square.release();
	Z_bool_single.release();

}

void ImageWidget::UpdateS_ADMM(float mu){
	Mat SA = I_x.rowRange(1, M).clone()*omega + (Z_x.rowRange(1, M).clone() - U_x.rowRange(1, M).clone())*mu;
	Mat SB = I_y.colRange(1, N).clone()*omega + (Z_y.colRange(1, N).clone() - U_y.colRange(1, N).clone())*mu;
	Mat SC = (Z_x.rowRange(0, M - 1).clone() - Z_y.colRange(0, N - 1).clone() - U_t.clone())*mu;
	float MS_time = mu / ((omega + mu)*(omega + 3 * mu));
	Mat MS = (SA.clone() + SB.clone())*MS_time;
	float beta = 1.0 / (omega + 3 * mu);
	Mat S_x_new = (SA.clone() + SC.clone())*beta + MS.clone();
	Mat S_y_new = (SB.clone() - SC.clone())*beta + MS.clone();
	S_x_new.copyTo(S_x.rowRange(1, M));
	S_y_new.copyTo(S_y.colRange(1, N));
	Mat row_exp = Z_x.row(0) + U_x.row(0);
	Mat col_exp = U_y.col(0) + U_y.col(0);
	S_x.row(0).copyTo(row_exp);
	S_y.col(0).copyTo(col_exp);
	SA.release();
	SB.release();
	SC.release();
	MS.release();
}

void ImageWidget::UpdateR_ADMM(){
	R_x = S_x - Z_x;
	R_y = S_y - Z_y;
	R_t = S_x.rowRange(1, M).clone() - S_y.colRange(1, N).clone() - Z_x.rowRange(0, M - 1).clone() + Z_y.colRange(0, N - 1).clone();
}

void ImageWidget::UpdateU_ADMM(){
	U_x = U_x + R_x;
	U_y = U_y + R_y;
	U_t = U_t + R_t;
}

float ImageWidget::getDeteR(){
	Mat R_x2, R_y2, R_t2;
	int p = 2;
	pow(R_x.clone(), p, R_x2);
	pow(R_y.clone(), p, R_y2);
	pow(R_t.clone(), p, R_t2);
	float DeteR = 0.0;
	DeteR = DeteR + sumMat(R_x2);
	DeteR = DeteR + sumMat(R_y2);
	DeteR = DeteR + sumMat(R_t2);
	DeteR = sqrt(DeteR);
	return DeteR;
}

float ImageWidget::getDeteS(){
	Mat Dete_Z_x2, Dete_Z_y2;
	int p = 2;
	pow(Dete_Z_x, p, Dete_Z_x2);
	pow(Dete_Z_y, p, Dete_Z_y2);
	float DeteS = 0.0;
	DeteS = DeteS + sumMat(Dete_Z_x2);
	DeteS = DeteS + sumMat(Dete_Z_y2);
	DeteS = sqrt(DeteS);
	return DeteS;
}

float ImageWidget::R_max(){
	float s, z;
	int p = 2;
	Mat S_x2, S_y2, S_t, S_t2;
	Mat Z_x2, Z_y2, Z_t, Z_t2;
	S_t = S_x.rowRange(1, M).clone() - S_y.colRange(1, N).clone();
	Z_t = Z_x.rowRange(0, M - 1).clone() - Z_y.colRange(0, N - 1).clone();
	pow(S_x, p, S_x2);
	pow(S_y, p, S_y2);
	pow(Z_x, p, Z_x2);
	pow(Z_y, p, Z_y2);
	pow(S_t, p, S_t2);
	pow(Z_t, p, Z_t2);
	s = 0; z = 0;
	s = s + sumMat(S_x2);
	s = s + sumMat(S_y2);
	s = s + sumMat(S_t2);
	z = z + sumMat(Z_x2);
	z = z + sumMat(Z_y2);
	z = z + sumMat(Z_t2);
	s = sqrt(s);
	z = sqrt(z);
	if (s > z){
		return s;
	}
	else{
		return z;
	}
}

float ImageWidget:: S_max(){
	float s = 0;
	Mat U_x2, U_y2, U_t2;
	int p = 2;
	pow(U_x, p, U_x2);
	pow(U_y, p, U_y2);
	pow(U_t, p, U_t2);
	s = s + sumMat(U_x2);
	s = s + sumMat(U_y2);
	s = s + sumMat(U_t2);
	return s;
}

float ImageWidget::R_Stop_Iter(){
	float num = 3 * M*N - 2 * M - 2 * N + 1;
	float r = 0.01*sqrt(num) + 0.0005*R_max();
	return r;
}


float ImageWidget::S_Stop_Iter(){
	float num = M*N;
	float s = 0.01*sqrt(num) + 0.0005*S_max();
	return s;
}

void ImageWidget::ADMM_L0Smoothing(){
	if (M>3 && N>3){
		float t1 = clock();
		float mu = 10 * omega;
		SetDiff();
		progress = 0;
		emit mysignal(progress);
		float RSI = 1.0;
		float SSI = 1.0;
		int i = 0;
		float DR = RSI + 0.1;
		float DS = SSI + 0.1;
		while ((DR>RSI||DS>SSI)&&i<18){
			UpdateZ_ADMM(mu);
			UpdateS_ADMM(mu);
			UpdateR_ADMM();
			UpdateU_ADMM();
			RSI = R_Stop_Iter();
			SSI = S_Stop_Iter();
			DR = getDeteR();
			DS = getDeteS();
			if (DR > 10 * DS){
				mu = mu * 2;
			}
			if (DS > 10 * DR){
				mu = mu / 2;
			}
			i++;
			progress = progress + 2;
			emit mysignal(progress);
		}
		//WriteCheck();
		Reconstruct();
		progress = 40;
		emit mysignal(progress);
		update();
		float t2 = clock();
		time = (t2 - t1) / CLOCKS_PER_SEC;
		emit mytime();
	}
}

void ImageWidget::UpdateS1(float mu){
	Mat allone_rgb[] = { cv::Mat::ones(M - 1, N - 1, CV_32F), cv::Mat::ones(M - 1, N - 1, CV_32F), cv::Mat::ones(M - 1, N - 1, CV_32F) };
	Mat allone;
	merge(allone_rgb, 3, allone);
	for (int i = 0; i < 10; i++){
		Mat denominator2 = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
		Mat mat_quare;
		Mat X_diff = S_x.rowRange(1, M) - I_x.rowRange(1, M);
		Mat Y_diff = S_y.colRange(1, N) - I_y.colRange(1, N);
		mat_quare = X_diff.mul(X_diff);
		denominator2 = denominator2 + mat_quare;
		mat_quare = Y_diff.mul(Y_diff);
		denominator2 = denominator2 + mat_quare;
		X_diff.release();
		Y_diff.release();
		Mat denominator;
		
		double pp = 0.5;
		pow(denominator2, pp, denominator);
		denominator = denominator + 0.00001*allone;

		Mat NS;
		NS = omega / denominator;

		mat_quare.release();
		denominator2.release();
		denominator.release();
		Mat NS1 = NS + mu * allone;
		Mat NS2 = NS + (mu * 2) * allone;
		Mat NS3 = NS + (mu * 3) * allone;
		Mat MS_den = NS1.mul(NS3);

		Mat MS;
		MS = 1.0 / MS_den;

		Mat SA = NS.mul(I_x.rowRange(1, M)) + mu*(Z_x.rowRange(1, M));
		Mat SB = NS.mul(I_y.colRange(1, N)) + mu*(Z_y.colRange(1, N));
		Mat SC = mu*(Z_x.rowRange(0, M - 1) - Z_y.colRange(0, N - 1));
		Mat S_x_new_ = NS2.mul(SA) + mu*SB + NS1.mul(SC);
		Mat S_y_new_ = mu*SA + NS2.mul(SB) - NS1.mul(SC);
		Mat S_x_new = MS.mul(S_x_new_);
		Mat S_y_new = MS.mul(S_y_new_);
		S_x_new_.release();
		S_y_new_.release();
		
		NS.release();
		NS1.release();
		NS2.release();
		NS3.release();
		MS.release();
		S_x_new.copyTo(S_x.rowRange(1, M));
		S_y_new.copyTo(S_y.colRange(1, N));
		S_x_new.release();
		S_y_new.release();
		Mat copy_row = Z_x.row(0);
		Mat copy_col = Z_y.col(0);
		copy_row.copyTo(S_x.row(0));
		copy_col.copyTo(S_y.col(0));
		copy_row.release();
		copy_col.release();
	}
}

void ImageWidget::UpdateS_ADMM1(float mu){
	Mat allone_rgb[] = { cv::Mat::ones(M - 1, N - 1, CV_32F), cv::Mat::ones(M - 1, N - 1, CV_32F), cv::Mat::ones(M - 1, N - 1, CV_32F) };
	Mat allone;
	merge(allone_rgb, 3, allone);
	for (int i = 0; i < 10; i++){
		Mat denominator2 = cv::Mat::zeros(M - 1, N - 1, CV_32FC3);
		Mat mat_quare;
		Mat X_diff = S_x.rowRange(1, M) - I_x.rowRange(1, M);
		Mat Y_diff = S_y.colRange(1, N) - I_y.colRange(1, N);
		mat_quare = X_diff.mul(X_diff);
		denominator2 = denominator2 + mat_quare;
		mat_quare = Y_diff.mul(Y_diff);
		denominator2 = denominator2 + mat_quare;
		X_diff.release();
		Y_diff.release();
		Mat denominator;

		double pp = 0.5;
		pow(denominator2, pp, denominator);
		denominator = denominator + 0.00001*allone;

		Mat NS;
		NS = omega / denominator;

		mat_quare.release();
		denominator2.release();
		denominator.release();
		Mat NS1 = NS + mu * allone;
		Mat NS2 = NS + (mu * 2) * allone;
		Mat NS3 = NS + (mu * 3) * allone;
		Mat MS_den = NS1.mul(NS3);

		Mat MS;
		MS = 1.0 / MS_den;

		Mat SA = NS.mul(I_x.rowRange(1, M)) + mu*(Z_x.rowRange(1, M) - U_x.rowRange(1, M));
		Mat SB = NS.mul(I_y.colRange(1, N)) + mu*(Z_y.colRange(1, N) - U_y.colRange(1, N));
		Mat SC = mu*(Z_x.rowRange(0, M - 1) - Z_y.colRange(0, N - 1) - U_t.clone());
		Mat S_x_new_ = NS2.mul(SA) + mu*SB + NS1.mul(SC);
		Mat S_y_new_ = mu*SA + NS2.mul(SB) - NS1.mul(SC);
		Mat S_x_new = MS.mul(S_x_new_);
		Mat S_y_new = MS.mul(S_y_new_);
		S_x_new_.release();
		S_y_new_.release();

		NS.release();
		NS1.release();
		NS2.release();
		NS3.release();
		MS.release();
		S_x_new.copyTo(S_x.rowRange(1, M));
		S_y_new.copyTo(S_y.colRange(1, N));
		S_x_new.release();
		S_y_new.release();
		Mat copy_row = Z_x.row(0) - U_x.row(0);
		Mat copy_col = Z_y.col(0) - U_y.col(0);
		copy_row.copyTo(S_x.row(0));
		copy_col.copyTo(S_y.col(0));
		copy_row.release();
		copy_col.release();
	} 
}

void ImageWidget::Penalty_Method_L0Smoothing1(){
	if (M>3 && N>3){
		float t1 = clock();
		float mu = 0.04;
		float mu_max = 10000;
		progress = 0;
		emit mysignal(progress);
		SetDiff();
		progress++;
		emit mysignal(progress);
		while (mu < mu_max){
			UpdateZ(mu);
			progress++;
			emit mysignal(progress);
			UpdateS1(mu);
			mu *= 2;
			progress++;
			emit mysignal(progress);
			step++;
		}
		Reconstruct();
		progress = 40;
		emit mysignal(progress);
		update();
		float t2 = clock();
		time = (t2 - t1) / CLOCKS_PER_SEC;
		emit mytime();
	}
}

void ImageWidget::ADMM_L0Smoothing1(){
	if (M>3 && N>3){
		float t1 = clock();
		float mu = 10 * omega;
		SetDiff();
		progress = 0;
		emit mysignal(progress);
		float RSI = 1.0;
		float SSI = 1.0;
		int i = 0;
		float DR = RSI + 0.1;
		float DS = SSI + 0.1;
		while ((DR>RSI || DS>SSI) && i<18){
			UpdateZ_ADMM(mu);
			UpdateS_ADMM1(mu);
			UpdateR_ADMM();
			UpdateU_ADMM();
			RSI = R_Stop_Iter();
			SSI = S_Stop_Iter();
			DR = getDeteR();
			DS = getDeteS();
			if (DR > 10 * DS){
				mu = mu * 2;
			}
			if (DS > 10 * DR){
				mu = mu / 2;
			}
			i++;
			progress = progress + 2;
			emit mysignal(progress);
		}
		Reconstruct();
		progress = 40;
		emit mysignal(progress);
		update();
		float t2 = clock();
		time = (t2 - t1) / CLOCKS_PER_SEC;
		emit mytime();
	}
}