#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtWidgets/QMainWindow>
#include <qpushbutton.h>
#include <qcombobox.h>
#include <qprogressbar.h>
#include "ui_mainwindow.h"

QT_BEGIN_NAMESPACE
	class QAction;
	class QMenu;
	class ViewWidget;
	class QImage;
	class QPainter;
	class QRect;
	class ImageWidget;
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	MainWindow(QWidget *parent = 0);
	~MainWindow();

protected:
	void closeEvent(QCloseEvent *e);
	void paintEvent(QPaintEvent *paintevent);

public slots:
	void setLineEditValue(int value);
	void setOmega(int value);
	void setSlider();
	void setOmega_();

public slots:
	void startProgress(int progress);
	void setTime();
	
private:
	void CreateActions();
	void CreateMenus();
	void CreateToolBars();
	void CreateStatusBar();
	void CreatSliderBar();
	void CreatProgressBar();
	void CreatComboBox();

public slots:
	void on_click_sel();

private:
	Ui::MainWindowClass ui;

	QMenu			*menu_file_;
	QMenu			*menu_edit_;
	QMenu			*menu_help_;
	QToolBar		*toolbar_file_;
	QToolBar		*toolbar_edit_;
	QAction			*action_open_;
	QAction			*action_save_;
	QAction			*action_saveas_;
	QSlider			*slider;
	QComboBox       *cb_method_;
	QComboBox		*cb_norm_;
	QPushButton		*btn;
	QLineEdit		*lineEdit;

	QProgressBar	*progressBar;

	ImageWidget		*imagewidget_;

	int p;
	bool method;

signals:
	void Barshow();
	void Barhide();
private slots:
	void ShowBar();
	void HideBar();
};

#endif // MAINWINDOW_H
