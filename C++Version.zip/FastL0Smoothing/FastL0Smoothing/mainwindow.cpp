#include "mainwindow.h"
#include <QtWidgets>
#include <QImage>
#include <QPainter>
#include "ImageWidget.h"



MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent)
{
	//ui.setupUi(this);

	setGeometry(300, 150, 800, 450);

	imagewidget_ = new ImageWidget();
	setCentralWidget(imagewidget_);

	p = 20;

	CreatSliderBar();
	CreatProgressBar();
	CreatComboBox();
	CreateActions();
	CreateMenus();
	CreateToolBars();
	CreateStatusBar();

}

MainWindow::~MainWindow()
{

}

void MainWindow::closeEvent(QCloseEvent *e)
{

}

void MainWindow::paintEvent(QPaintEvent* paintevent)
{
	
}

void MainWindow::setLineEditValue(int value)
{
	int pos = slider->value();
	QString str = QString("%1").arg(pos);
	lineEdit->setText(str);
}

void MainWindow::setSlider()
{
	QString str = lineEdit->text();
	int pos = str.toInt();
	slider->setValue(pos);
}

void MainWindow::setOmega(int value)
{
	int pos = slider->value();
	float omega = (float)pos;
	imagewidget_->set_omega(omega);
}

void MainWindow::setOmega_()
{
	int pos = (lineEdit->text()).toInt();
	float omega = (float)pos;
	imagewidget_->set_omega(omega);
}

void MainWindow::startProgress(int progress)
{
	p = imagewidget_->get_progress();
	progressBar->setValue(p);
	if (p > 0 && p < 40){
		emit Barshow();
	}
	else{
		emit Barhide();
	}
}

void MainWindow::CreateActions()
{
	QPixmap  *pixmap_open = NULL;
	pixmap_open = new QPixmap(32, 32);
	pixmap_open->load(":/Resources/images/open.png.png");
	QIcon *icon_start = new QIcon(*pixmap_open);
	action_open_ = new QAction(*icon_start, tr("&Open..."), this);
	action_open_->setShortcuts(QKeySequence::Open);
	action_open_->setStatusTip(tr("Open an existing file"));
	connect(action_open_, SIGNAL(triggered()), imagewidget_, SLOT(Open()));

	QPixmap  *pixmap_save = NULL;
	pixmap_save = new QPixmap(32, 32);
	pixmap_save->load(":/Resources/images/save.png.png");
	QIcon *icon_save = new QIcon(*pixmap_save);
	action_save_ = new QAction(*pixmap_save, tr("&Save"), this);
	action_save_->setShortcuts(QKeySequence::Save);
	action_save_->setStatusTip(tr("Save the document to disk"));
	connect(action_save_, SIGNAL(triggered()), imagewidget_, SLOT(Save()));

	action_saveas_ = new QAction(tr("Save &As..."), this);
	action_saveas_->setShortcuts(QKeySequence::SaveAs);
	action_saveas_->setStatusTip(tr("Save the document under a new name"));
	connect(action_saveas_, SIGNAL(triggered()), imagewidget_, SLOT(SaveAs()));

	connect(slider, SIGNAL(valueChanged(int)), this, SLOT(setLineEditValue(int)));
	connect(slider, SIGNAL(valueChanged(int)), this, SLOT(setOmega(int)));

	connect(lineEdit, SIGNAL(textChanged(const QString&)), this, SLOT(setSlider()));
	connect(lineEdit, SIGNAL(textChanged(const QString&)), this, SLOT(setOmega_()));

	connect(imagewidget_, SIGNAL(mysignal(int)), this, SLOT(startProgress(int)));

	connect(this, SIGNAL(Barshow()), this, SLOT(ShowBar()));
	connect(this, SIGNAL(Barhide()), this, SLOT(HideBar()));

	connect(imagewidget_, SIGNAL(mytime()), this, SLOT(setTime()));

	connect(btn, SIGNAL(clicked()), this, SLOT(on_click_sel()));


}

void MainWindow::CreateMenus()
{
	menu_file_ = menuBar()->addMenu(tr("&File"));
	menu_file_->setStatusTip(tr("File menu"));
	menu_file_->addAction(action_open_);
	menu_file_->addAction(action_save_);
	menu_file_->addAction(action_saveas_);

	menu_edit_ = menuBar()->addMenu(tr("&Edit"));
	menu_edit_->setStatusTip(tr("Edit menu"));
}

void MainWindow::CreateToolBars()
{
	toolbar_file_ = addToolBar(tr("File"));
	toolbar_file_->addAction(action_open_);
	toolbar_file_->addAction(action_save_);

	// Add separator in toolbar 
	toolbar_file_->addSeparator();
	toolbar_file_->addWidget(cb_method_);
	toolbar_file_->addWidget(cb_norm_);
	toolbar_file_->addWidget(btn);

	toolbar_file_->addSeparator();
	toolbar_file_->addWidget(slider);
	toolbar_file_->addWidget(lineEdit);
	toolbar_file_->addSeparator();
	toolbar_file_->addWidget(progressBar);
	progressBar->setVisible(false);


}

void MainWindow::CreateStatusBar()
{
	statusBar()->showMessage(tr("Ready"));
}

void MainWindow::CreatSliderBar()
{
	lineEdit = new QLineEdit("2");
	slider = new QSlider(Qt::Horizontal);
	slider->setMinimum(0);
	slider->setMaximum(1000);
	slider->setAcceptDrops(true);
	QSize size(100, 25);
	slider->setBaseSize(size);
	lineEdit->setBaseSize(size);
	slider->setMaximumHeight(20);
	slider->setMaximumWidth(80);
	lineEdit->setMaximumHeight(20);
	lineEdit->setMaximumWidth(50);
}


void MainWindow::CreatProgressBar(){
	progressBar = new QProgressBar;
	progressBar->setFormat("%p%");
	progressBar->setRange(0, 40);
	QSize size(100, 25);
	progressBar->setBaseSize(size);
	progressBar->setMaximumHeight(20);
	progressBar->setMaximumWidth(120);
}

void MainWindow::ShowBar(){
	progressBar->setHidden(false);
}

void MainWindow::HideBar(){
	progressBar->setVisible(false);
}

void MainWindow::setTime(){
	QString s;
	float t = imagewidget_->get_time();
	s.sprintf("Running Time %.2fs", t);
	statusBar()->showMessage(s);
}

void MainWindow::CreatComboBox(){
	cb_method_ = new QComboBox();
	cb_method_->addItem(QWidget::tr("Penalty Method"));
	cb_method_->addItem(QWidget::tr("ADMM"));
	cb_method_->insertSeparator(2);
	cb_norm_ = new QComboBox();
	cb_norm_->addItem(QWidget::tr("L22 residue norm"));
	cb_norm_->addItem(QWidget::tr("L21 residue norm"));
	cb_norm_->insertSeparator(2);
	QIcon *icon_start = new QIcon(":\\Resources\\images\\start.ico");
	btn = new QPushButton(*icon_start, QWidget::tr("Smoothing"), this);
}

void MainWindow::on_click_sel(){
	int k = cb_method_->currentIndex();
	int b = cb_norm_->currentIndex();
	switch (k+2*b){
	case 0:imagewidget_->Penalty_Method_L0Smoothing(); break;
	case 1:imagewidget_->ADMM_L0Smoothing(); break;
	case 2:imagewidget_->Penalty_Method_L0Smoothing1(); break;
	case 3:imagewidget_->ADMM_L0Smoothing1(); break;
	default:break;
	}

}